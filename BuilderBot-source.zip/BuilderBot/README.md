# BuilderBot (Fabric, Minecraft Java 1.21.11)

BuilderBot adds a visible, named villager NPC that navigates around a planned build while the server constructs it from real block states. It uses a deterministic procedural planner, not an online AI service. Natural-language prompts are interpreted locally with keywords such as `castle`, `tower`, `modern`, `mansion`, `3-story`, `pool`, `farm`, `wall`, `bridge`, `large`, and `stone`.

## Commands

- `/builder spawn`
- `/builder build house`
- `/builder build castle`
- `/builder build tower`
- `/builder build pool`
- `/builder build mansion`
- `/builder build farm`
- `/builder build wall`
- `/builder build bridge`
- `/builder build prompt modern 3-story mansion with a swimming pool`
- `/builder build <supported-structure-or-keyword-description>`
- `/builder stop`
- `/builder resume`
- `/builder despawn`

Builds are placed five blocks in front of the player. In Survival, BuilderBot consumes matching block items from the command user's inventory as it places blocks and pauses when it runs out; Creative mode is free. Existing non-replaceable blocks above the ground layer are left intact, so some planned blocks can be skipped in cluttered areas. The bot uses vanilla villager navigation; block placement is server-side construction logic rather than a player entity physically swinging its arm for every block.

## Build

Requires JDK 21 and network access to the Fabric/Maven/Gradle repositories. Run:

```sh
./gradlew build
```

The installable remapped mod should be at `build/libs/builderbot-1.0.0.jar` after a successful build. Copy that JAR into `.minecraft/mods` alongside Fabric Loader and a matching Fabric API build.

## Current verification status

The source project and Gradle build configuration are provided. This execution environment has Java 21 but does not have Gradle installed and cannot resolve external hosts, so dependency resolution, compilation, and in-game testing could not be performed here. Do not treat the JAR as built until the Gradle build completes successfully in a network-enabled Java development environment.
