package com.winterarc.builderbot;

import com.mojang.brigadier.arguments.StringArgumentType;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.entity.Entity;
import net.minecraft.entity.SpawnReason;
import net.minecraft.entity.passive.VillagerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

import java.util.*;

import static net.minecraft.server.command.CommandManager.argument;
import static net.minecraft.server.command.CommandManager.literal;

public class BuilderBotMod implements ModInitializer {
    @Override public void onInitialize() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> dispatcher.register(
            literal("builder")
                .then(literal("spawn").executes(ctx -> BuilderManager.spawn(ctx.getSource())))
                .then(literal("despawn").executes(ctx -> BuilderManager.despawn(ctx.getSource())))
                .then(literal("stop").executes(ctx -> BuilderManager.stop(ctx.getSource())))
                .then(literal("resume").executes(ctx -> BuilderManager.resume(ctx.getSource())))
                .then(literal("build")
                    .then(literal("house").executes(ctx -> BuilderManager.build(ctx.getSource(), "house")))
                    .then(literal("castle").executes(ctx -> BuilderManager.build(ctx.getSource(), "castle")))
                    .then(literal("tower").executes(ctx -> BuilderManager.build(ctx.getSource(), "tower")))
                    .then(literal("pool").executes(ctx -> BuilderManager.build(ctx.getSource(), "pool")))
                    .then(literal("mansion").executes(ctx -> BuilderManager.build(ctx.getSource(), "modern 3-story mansion with a swimming pool")))
                    .then(literal("prompt").then(argument("description", StringArgumentType.greedyString())
                        .executes(ctx -> BuilderManager.build(ctx.getSource(), StringArgumentType.getString(ctx, "description")))))
                    .then(argument("structure", StringArgumentType.word()).executes(ctx -> BuilderManager.build(ctx.getSource(), StringArgumentType.getString(ctx, "structure"))))
                )
        ));
        ServerTickEvents.END_SERVER_TICK.register(BuilderManager::tick);
    }
}

final class BuilderManager {
    private static final Map<UUID, BotState> BOTS = new HashMap<>();
    private static final int MAX_BLOCKS = 16000;
    private BuilderManager() {}

    static int spawn(ServerCommandSource source) throws com.mojang.brigadier.exceptions.CommandSyntaxException {
        ServerPlayerEntity player = source.getPlayerOrThrow();
        ServerWorld world = player.getServerWorld();
        BotState old = BOTS.remove(player.getUuid());
        if (old != null) old.bot.discard();
        VillagerEntity bot = EntityTypeHelper.createVillager(world);
        if (bot == null) { source.sendError(Text.literal("Could not create BuilderBot in this world.")); return 0; }
        Vec3d look = player.getRotationVec(1.0f);
        BlockPos spawn = BlockPos.ofFloored(player.getX() + look.x * 2.0, player.getY(), player.getZ() + look.z * 2.0);
        bot.refreshPositionAndAngles(spawn.getX() + 0.5, spawn.getY(), spawn.getZ() + 0.5, player.getYaw(), 0);
        bot.setCustomName(Text.literal("BuilderBot"));
        bot.setCustomNameVisible(true);
        bot.setPersistent();
        bot.setAiDisabled(false);
        world.spawnEntity(bot);
        BOTS.put(player.getUuid(), new BotState(player.getUuid(), world, bot));
        source.sendFeedback(() -> Text.literal("BuilderBot spawned. Try /builder build house or /builder build prompt <description>."), false);
        return 1;
    }

    static int despawn(ServerCommandSource source) throws com.mojang.brigadier.exceptions.CommandSyntaxException {
        BotState s = get(source);
        if (s == null) return missing(source);
        s.bot.discard(); BOTS.remove(s.owner);
        source.sendFeedback(() -> Text.literal("BuilderBot despawned."), false); return 1;
    }
    static int stop(ServerCommandSource source) throws com.mojang.brigadier.exceptions.CommandSyntaxException {
        BotState s = get(source); if (s == null) return missing(source);
        s.paused = true; s.bot.getNavigation().stop();
        source.sendFeedback(() -> Text.literal("BuilderBot paused at " + s.placed + "/" + s.plan.size() + " blocks."), false); return 1;
    }
    static int resume(ServerCommandSource source) throws com.mojang.brigadier.exceptions.CommandSyntaxException {
        BotState s = get(source); if (s == null) return missing(source);
        s.paused = false; source.sendFeedback(() -> Text.literal("BuilderBot resumed."), false); return 1;
    }
    static int build(ServerCommandSource source, String description) throws com.mojang.brigadier.exceptions.CommandSyntaxException {
        BotState s = get(source); if (s == null) return missing(source);
        ServerPlayerEntity player = source.getPlayerOrThrow();
        String d = description.toLowerCase(Locale.ROOT);
        BlockPos origin = BlockPos.ofFloored(player.getX(), player.getY(), player.getZ()).offset(player.getHorizontalFacing(), 5);
        StructurePlan plan = StructurePlan.create(d, origin);
        if (plan.blocks.size() > MAX_BLOCKS) { source.sendError(Text.literal("That structure is too large. Try a smaller design.")); return 0; }
        s.plan.clear(); s.plan.addAll(plan.blocks);
        s.cursor = 0; s.placed = 0; s.paused = false; s.owner = player.getUuid(); s.world = player.getServerWorld();
        s.origin = origin; s.lastMoveTick = 0; s.missingMaterial = false;
        source.sendFeedback(() -> Text.literal("BuilderBot planned '" + plan.name + "' — " + s.plan.size() + " blocks. Construction started."), false);
        return 1;
    }
    static void tick(MinecraftServer server) {
        Iterator<BotState> it = BOTS.values().iterator();
        while (it.hasNext()) {
            BotState s = it.next();
            if (s.bot.isRemoved() || !s.world.getServer().equals(server)) { it.remove(); continue; }
            if (s.paused || s.cursor >= s.plan.size()) continue;
            ServerPlayerEntity owner = server.getPlayerManager().getPlayer(s.owner);
            if (owner == null || owner.isRemoved()) continue;
            if (s.world.getTime() % 2 != 0) continue;
            PlannedBlock next = s.plan.get(s.cursor);
            BlockPos p = next.pos;
            if (next.state.isAir()) { s.cursor++; continue; }
            // Move around the footprint at ground level while the server places the planned blocks.
            BlockPos walkTarget = new BlockPos(p.getX(), s.origin.getY(), p.getZ());
            if (s.world.getTime() - s.lastMoveTick > 30 || s.bot.getNavigation().isIdle()) {
                s.bot.getNavigation().startMovingTo(walkTarget.getX() + 0.5, walkTarget.getY(), walkTarget.getZ() + 0.5, 1.0);
                s.lastMoveTick = s.world.getTime();
            }
            double dx = s.bot.getX() - (p.getX() + 0.5);
            double dz = s.bot.getZ() - (p.getZ() + 0.5);
            if (dx * dx + dz * dz > 100.0) continue;
            BlockState existing = s.world.getBlockState(p);
            if (p.getY() > s.origin.getY() && !existing.isAir() && !existing.isReplaceable()) { s.cursor++; continue; }
            if (!owner.isCreative()) {
                Item needed = next.state.getBlock().asItem();
                if (needed == net.minecraft.item.Items.AIR || !removeOne(owner, needed)) {
                    s.paused = true; s.missingMaterial = true;
                    owner.sendMessage(Text.literal("BuilderBot paused: missing " + next.state.getBlock().getName().getString() + ". Gather materials, then use /builder resume."), false);
                    continue;
                }
            }
            s.world.setBlockState(p, next.state, Block.NOTIFY_ALL);
            s.cursor++; s.placed++;
            if (s.cursor % 100 == 0) owner.sendMessage(Text.literal("BuilderBot progress: " + s.cursor + "/" + s.plan.size() + " blocks."), false);
            if (s.cursor >= s.plan.size()) {
                s.bot.getNavigation().stop();
                owner.sendMessage(Text.literal("BuilderBot finished! Placed " + s.placed + " blocks."), false);
            }
        }
    }
    private static boolean removeOne(ServerPlayerEntity player, Item item) {
        for (int i = 0; i < player.getInventory().size(); i++) {
            ItemStack stack = player.getInventory().getStack(i);
            if (!stack.isEmpty() && stack.isOf(item)) { stack.decrement(1); return true; }
        }
        return false;
    }
    private static BotState get(ServerCommandSource source) throws com.mojang.brigadier.exceptions.CommandSyntaxException {
        return BOTS.get(source.getPlayerOrThrow().getUuid());
    }
    private static int missing(ServerCommandSource source) {
        source.sendError(Text.literal("You do not have a BuilderBot. Use /builder spawn first.")); return 0;
    }
}

final class EntityTypeHelper {
    static VillagerEntity createVillager(ServerWorld world) {
        Entity entity = net.minecraft.entity.EntityType.VILLAGER.create(world, SpawnReason.COMMAND);
        return entity instanceof VillagerEntity villager ? villager : null;
    }
}

final class BotState {
    UUID owner; final VillagerEntity bot; ServerWorld world; BlockPos origin;
    final List<PlannedBlock> plan = new ArrayList<>(); int cursor, placed; boolean paused, missingMaterial; long lastMoveTick;
    BotState(UUID owner, ServerWorld world, VillagerEntity bot) { this.owner = owner; this.world = world; this.bot = bot; }
}
record PlannedBlock(BlockPos pos, BlockState state) {}

final class StructurePlan {
    final String name; final List<PlannedBlock> blocks = new ArrayList<>();
    private StructurePlan(String name) { this.name = name; }
    private void put(int x, int y, int z, BlockState state) { blocks.add(new PlannedBlock(new BlockPos(x,y,z), state)); }
    static StructurePlan create(String description, BlockPos o) {
        String d = description.toLowerCase(Locale.ROOT);
        if (d.contains("castle")) return castle(o);
        if (d.contains("tower")) return tower(o);
        if (d.contains("pool") && !d.contains("house") && !d.contains("mansion")) return pool(o);
        if (d.contains("bridge")) return bridge(o);
        if (d.contains("modern") || d.contains("mansion") || d.contains("story") || d.contains("pool")) return mansion(o, d);
        if (d.contains("farm")) return farm(o);
        if (d.contains("wall")) return wall(o);
        return house(o, d);
    }
    private static StructurePlan house(BlockPos o, String d) {
        StructurePlan p = new StructurePlan("house"); int w = d.contains("large") || d.contains("big") ? 11 : 7; int h = d.contains("two") || d.contains("2-story") ? 7 : 4;
        BlockState floor = d.contains("stone") ? Blocks.STONE_BRICKS.getDefaultState() : Blocks.OAK_PLANKS.getDefaultState();
        BlockState wall = d.contains("stone") ? Blocks.STONE_BRICKS.getDefaultState() : Blocks.OAK_PLANKS.getDefaultState();
        shell(p,o,w,w,h,floor,wall,Blocks.SPRUCE_PLANKS.getDefaultState());
        p.put(o.getX()+w/2,o.getY()+1,o.getZ(),Blocks.AIR.getDefaultState()); p.put(o.getX()+w/2,o.getY()+2,o.getZ(),Blocks.AIR.getDefaultState());
        for (int y=1;y<h-1;y++) { p.put(o.getX()+1,o.getY()+y,o.getZ()+w/2,Blocks.GLASS_PANE.getDefaultState()); p.put(o.getX()+w-2,o.getY()+y,o.getZ()+w/2,Blocks.GLASS_PANE.getDefaultState()); }
        return p;
    }
    private static void shell(StructurePlan p, BlockPos o, int w, int l, int h, BlockState floor, BlockState wall, BlockState roof) {
        for(int x=0;x<w;x++) for(int z=0;z<l;z++) p.put(o.getX()+x,o.getY(),o.getZ()+z,floor);
        for(int y=1;y<=h;y++) for(int x=0;x<w;x++) for(int z=0;z<l;z++) if(x==0||z==0||x==w-1||z==l-1) p.put(o.getX()+x,o.getY()+y,o.getZ()+z,wall);
        for(int x=0;x<w;x++) for(int z=0;z<l;z++) p.put(o.getX()+x,o.getY()+h+1,o.getZ()+z,roof);
    }
    private static StructurePlan mansion(BlockPos o, String d) {
        StructurePlan p = new StructurePlan("modern mansion"); int levels = d.contains("3-story") || d.contains("three") ? 3 : 2; int w=15,l=13;
        for(int level=0;level<levels;level++) {
            int y=level*4; BlockState floor=Blocks.QUARTZ_BLOCK.getDefaultState(), wall=Blocks.WHITE_CONCRETE.getDefaultState();
            for(int x=0;x<w;x++) for(int z=0;z<l;z++) p.put(o.getX()+x,o.getY()+y,o.getZ()+z,floor);
            for(int yy=1;yy<=3;yy++) for(int x=0;x<w;x++) for(int z=0;z<l;z++) if(x==0||z==0||x==w-1||z==l-1) p.put(o.getX()+x,o.getY()+y+yy,o.getZ()+z,((x+z+yy)%3==0)?Blocks.GLASS.getDefaultState():wall);
            for(int x=0;x<w;x++) for(int z=0;z<l;z++) p.put(o.getX()+x,o.getY()+y+4,o.getZ()+z,Blocks.SMOOTH_QUARTZ.getDefaultState());
        }
        if(d.contains("pool")) for(int x=18;x<26;x++) for(int z=2;z<8;z++) { p.put(o.getX()+x,o.getY(),o.getZ()+z,Blocks.SMOOTH_STONE.getDefaultState()); p.put(o.getX()+x,o.getY()+1,o.getZ()+z,Blocks.WATER.getDefaultState()); }
        return p;
    }
    private static StructurePlan castle(BlockPos o) {
        StructurePlan p = new StructurePlan("castle"); int w=21,l=21,h=7; BlockState stone=Blocks.STONE_BRICKS.getDefaultState();
        shell(p,o,w,l,h,stone,stone,Blocks.DEEPSLATE_BRICKS.getDefaultState());
        for(int cx:new int[]{0,w-4}) for(int cz:new int[]{0,l-4}) for(int y=1;y<=12;y++) for(int x=0;x<4;x++) for(int z=0;z<4;z++) if(x==0||z==0||x==3||z==3) p.put(o.getX()+cx+x,o.getY()+y,o.getZ()+cz+z,stone);
        for(int x=8;x<13;x++) for(int y=1;y<4;y++) p.put(o.getX()+x,o.getY()+y,o.getZ(),Blocks.AIR.getDefaultState());
        for(int x=0;x<w;x++) for(int z=0;z<l;z++) if((x+z)%2==0) p.put(o.getX()+x,o.getY()+h+2,o.getZ()+z,Blocks.STONE_BRICK_WALL.getDefaultState());
        return p;
    }
    private static StructurePlan tower(BlockPos o) { StructurePlan p=new StructurePlan("tower"); for(int y=0;y<18;y++) for(int x=0;x<9;x++) for(int z=0;z<9;z++) if(x==0||z==0||x==8||z==8||y==0||y==17) p.put(o.getX()+x,o.getY()+y,o.getZ()+z,Blocks.STONE_BRICKS.getDefaultState()); for(int y=1;y<17;y+=4) for(int x=2;x<7;x++) for(int z=2;z<7;z++) p.put(o.getX()+x,o.getY()+y,o.getZ()+z,Blocks.OAK_PLANKS.getDefaultState()); return p; }
    private static StructurePlan pool(BlockPos o) { StructurePlan p=new StructurePlan("swimming pool"); for(int x=0;x<11;x++) for(int z=0;z<7;z++){p.put(o.getX()+x,o.getY(),o.getZ()+z,Blocks.SMOOTH_STONE.getDefaultState()); if(x==0||z==0||x==10||z==6) p.put(o.getX()+x,o.getY()+1,o.getZ()+z,Blocks.QUARTZ_BLOCK.getDefaultState()); else p.put(o.getX()+x,o.getY()+1,o.getZ()+z,Blocks.WATER.getDefaultState());} return p; }
    private static StructurePlan farm(BlockPos o) { StructurePlan p=new StructurePlan("farm"); for(int x=0;x<13;x++) for(int z=0;z<9;z++){p.put(o.getX()+x,o.getY(),o.getZ()+z,Blocks.FARMLAND.getDefaultState()); if(x%3==1&&z%2==1) p.put(o.getX()+x,o.getY()+1,o.getZ()+z,Blocks.WHEAT.getDefaultState());} for(int x=0;x<13;x++){p.put(o.getX()+x,o.getY()+1,o.getZ(),Blocks.OAK_FENCE.getDefaultState());p.put(o.getX()+x,o.getY()+1,o.getZ()+8,Blocks.OAK_FENCE.getDefaultState());} return p; }
    private static StructurePlan wall(BlockPos o) { StructurePlan p=new StructurePlan("wall"); for(int x=0;x<25;x++) for(int y=0;y<5;y++) p.put(o.getX()+x,o.getY()+y,o.getZ(),Blocks.STONE_BRICKS.getDefaultState()); return p; }
    private static StructurePlan bridge(BlockPos o) { StructurePlan p=new StructurePlan("bridge"); for(int x=0;x<17;x++) for(int z=0;z<5;z++) {p.put(o.getX()+x,o.getY(),o.getZ()+z,Blocks.OAK_PLANKS.getDefaultState()); if(z==0||z==4) p.put(o.getX()+x,o.getY()+1,o.getZ()+z,Blocks.OAK_FENCE.getDefaultState());} return p; }
}
